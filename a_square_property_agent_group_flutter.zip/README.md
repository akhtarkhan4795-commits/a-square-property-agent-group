# A. Square Property Agent Group

Flutter starter app for A. Square Property Agent Group.

The app branding/profile name has been updated to **A. Square Property Agent Group**.
Akhtar Khan remains the agent profile.

## Run
flutter pub get
flutter run

## Build APK
flutter build apk --release

Release APK:
build/app/outputs/flutter-apk/app-release.apk
