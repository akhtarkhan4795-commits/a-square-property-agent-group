import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(const ASquareApp());
}

class ASquareApp extends StatelessWidget {
  const ASquareApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'A. Square Property Agent Group',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        scaffoldBackgroundColor: const Color(0xFFF6F8FC),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1265D8),
          brightness: Brightness.light,
        ),
        fontFamily: 'Roboto',
      ),
      home: const HomePage(),
    );
  }
}

class Property {
  final String title;
  final String category;
  final String location;
  final String price;
  final String size;
  final String description;
  final IconData icon;

  const Property({
    required this.title,
    required this.category,
    required this.location,
    required this.price,
    required this.size,
    required this.description,
    required this.icon,
  });
}

const properties = <Property>[
  Property(
    title: 'Premium Residential Plot',
    category: 'Residential Plot',
    location: 'Barkachha, Mirzapur',
    price: 'Price on Call',
    size: '1200 sq.ft',
    description: 'Residential plot with road access and a suitable location for family living and investment.',
    icon: Icons.home_work_rounded,
  ),
  Property(
    title: 'Residential Land',
    category: 'Residential Plot',
    location: 'Arjunpur Road, Mirzapur',
    price: 'Price on Call',
    size: '1000 sq.ft',
    description: 'Well-connected residential land with a clean environment and nearby facilities.',
    icon: Icons.location_city_rounded,
  ),
  Property(
    title: 'Agriculture Land',
    category: 'Agriculture',
    location: 'Mirzapur District',
    price: 'Price on Call',
    size: '1 Bigha+',
    description: 'Agricultural land option for long-term investment and farming use.',
    icon: Icons.agriculture_rounded,
  ),
  Property(
    title: 'Commercial Plot',
    category: 'Commercial',
    location: 'Mirzapur',
    price: 'Price on Call',
    size: 'Custom',
    description: 'Commercial property option for business and investment requirements.',
    icon: Icons.storefront_rounded,
  ),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int currentIndex = 0;
  String search = '';

  Future<void> _call() async {
    final uri = Uri(scheme: 'tel', path: '8299702322');
    await launchUrl(uri);
  }

  Future<void> _whatsapp() async {
    final uri = Uri.parse(
      'https://wa.me/918604482766?text=${Uri.encodeComponent("Hello A. Square Property Agent Group, I am interested in a property.")}',
    );
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _homeBody(),
      _propertyBody(),
      const ProfilePage(),
    ];

    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        titleSpacing: 16,
        title: Row(
          children: [
            Image.asset('assets/logo.png', width: 42, height: 42),
            const SizedBox(width: 10),
            const Expanded(
              child: Text(
                'A. Square Property Agent Group',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Call',
            onPressed: _call,
            icon: const Icon(Icons.call_rounded),
          ),
        ],
      ),
      body: pages[currentIndex],
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _whatsapp,
        icon: const Icon(Icons.chat_rounded),
        label: const Text('WhatsApp'),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: currentIndex,
        onDestinationSelected: (value) => setState(() => currentIndex = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.search_outlined), selectedIcon: Icon(Icons.search), label: 'Properties'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }

  Widget _homeBody() {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 100),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _heroCard(),
          const SizedBox(height: 18),
          const Text('Find Your Property', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          TextField(
            onChanged: (value) => setState(() => search = value),
            decoration: InputDecoration(
              hintText: 'Search by location or property type',
              prefixIcon: const Icon(Icons.search_rounded),
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(18),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 18),
          _categories(),
          const SizedBox(height: 22),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Featured Properties', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              TextButton(
                onPressed: () => setState(() => currentIndex = 1),
                child: const Text('View All'),
              ),
            ],
          ),
          ..._filteredProperties().take(3).map(_propertyCard),
          const SizedBox(height: 20),
          _agentBanner(),
        ],
      ),
    );
  }

  Widget _heroCard() {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: const LinearGradient(
          colors: [Color(0xFF0B3B91), Color(0xFF1478E8)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(.12), blurRadius: 20, offset: const Offset(0, 10)),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                Text('Your Property,\\nOur Priority', style: TextStyle(color: Colors.white, fontSize: 27, fontWeight: FontWeight.w900)),
                SizedBox(height: 8),
                Text('Plots • Land • Flats • Commercial', style: TextStyle(color: Colors.white70, fontSize: 14)),
                SizedBox(height: 14),
                Text('“मैं सपने नहीं, हकीकत बेचता हूं”', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
          const SizedBox(width: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Image.asset('assets/logo.png', width: 88, height: 88, fit: BoxFit.cover),
          ),
        ],
      ),
    );
  }

  Widget _categories() {
    final cats = [
      ('Residential', Icons.home_rounded),
      ('Agriculture', Icons.agriculture_rounded),
      ('Commercial', Icons.storefront_rounded),
      ('Flats', Icons.apartment_rounded),
    ];
    return SizedBox(
      height: 105,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: cats.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (_, i) => GestureDetector(
          onTap: () => setState(() {
            search = cats[i].$1 == 'Residential' ? 'Residential Plot' : cats[i].$1;
            currentIndex = 1;
          }),
          child: Container(
            width: 100,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFFE3E8F2)),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(cats[i].$2, size: 30, color: const Color(0xFF1265D8)),
                const SizedBox(height: 7),
                Text(cats[i].$1, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  List<Property> _filteredProperties() {
    final q = search.trim().toLowerCase();
    if (q.isEmpty) return properties;
    return properties.where((p) =>
      p.title.toLowerCase().contains(q) ||
      p.category.toLowerCase().contains(q) ||
      p.location.toLowerCase().contains(q)
    ).toList();
  }

  Widget _propertyCard(Property p) {
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      color: Colors.white,
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PropertyDetailPage(property: p))),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Container(
                width: 88,
                height: 88,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(17),
                  gradient: const LinearGradient(colors: [Color(0xFFE9F2FF), Color(0xFFD8E9FF)]),
                ),
                child: Icon(p.icon, size: 42, color: const Color(0xFF1265D8)),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(p.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                    const SizedBox(height: 5),
                    Text(p.location, style: const TextStyle(color: Colors.black54)),
                    const SizedBox(height: 7),
                    Text('${p.size} • ${p.price}', style: const TextStyle(fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded),
            ],
          ),
        ),
      ),
    );
  }

  Widget _agentBanner() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 30,
            backgroundColor: const Color(0xFFEAF2FF),
            child: Image.asset('assets/logo.png', width: 44, height: 44),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Akhtar Khan', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                Text('Real Estate Agent • Mirzapur', style: TextStyle(color: Colors.black54)),
              ],
            ),
          ),
          IconButton(onPressed: _whatsapp, icon: const Icon(Icons.chat_rounded)),
        ],
      ),
    );
  }

  Widget _propertyBody() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 100),
      children: [
        TextField(
          onChanged: (value) => setState(() => search = value),
          decoration: InputDecoration(
            hintText: 'Search properties...',
            prefixIcon: const Icon(Icons.search_rounded),
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
          ),
        ),
        const SizedBox(height: 18),
        ..._filteredProperties().map(_propertyCard),
        if (_filteredProperties().isEmpty)
          const Padding(
            padding: EdgeInsets.all(40),
            child: Center(child: Text('No property found. Contact us for more options.')),
          ),
      ],
    );
  }
}

class PropertyDetailPage extends StatelessWidget {
  final Property property;
  const PropertyDetailPage({super.key, required this.property});

  Future<void> _call() async {
    await launchUrl(Uri(scheme: 'tel', path: '8299702322'));
  }

  Future<void> _whatsapp() async {
    final msg = 'Hello, I am interested in ${property.title} at ${property.location}. Please share details.';
    await launchUrl(
      Uri.parse('https://wa.me/918604482766?text=${Uri.encodeComponent(msg)}'),
      mode: LaunchMode.externalApplication,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Property Details')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            height: 220,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(28),
              gradient: const LinearGradient(colors: [Color(0xFFEAF2FF), Color(0xFFD7E8FF)]),
            ),
            child: Icon(property.icon, size: 90, color: const Color(0xFF1265D8)),
          ),
          const SizedBox(height: 20),
          Text(property.title, style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Text(property.location, style: const TextStyle(fontSize: 16, color: Colors.black54)),
          const SizedBox(height: 18),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              _chip(Icons.category_rounded, property.category),
              _chip(Icons.square_foot_rounded, property.size),
              _chip(Icons.payments_rounded, property.price),
            ],
          ),
          const SizedBox(height: 24),
          const Text('About this property', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
          const SizedBox(height: 8),
          Text(property.description, style: const TextStyle(fontSize: 16, height: 1.5, color: Colors.black87)),
          const SizedBox(height: 28),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: _call,
                  icon: const Icon(Icons.call_rounded),
                  label: const Text('Call'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton.icon(
                  onPressed: _whatsapp,
                  icon: const Icon(Icons.chat_rounded),
                  label: const Text('WhatsApp'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => EnquiryPage(property: property))),
            icon: const Icon(Icons.edit_note_rounded),
            label: const Text('Send Enquiry'),
          ),
        ],
      ),
    );
  }

  Widget _chip(IconData icon, String text) {
    return Chip(
      avatar: Icon(icon, size: 18),
      label: Text(text),
      side: BorderSide.none,
      backgroundColor: const Color(0xFFEAF2FF),
    );
  }
}

class EnquiryPage extends StatefulWidget {
  final Property property;
  const EnquiryPage({super.key, required this.property});

  @override
  State<EnquiryPage> createState() => _EnquiryPageState();
}

class _EnquiryPageState extends State<EnquiryPage> {
  final name = TextEditingController();
  final phone = TextEditingController();
  final message = TextEditingController();

  void submit() {
    if (name.text.trim().isEmpty || phone.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter your name and phone number.')),
      );
      return;
    }
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Enquiry saved in this demo version.')),
    );
  }

  @override
  void dispose() {
    name.dispose();
    phone.dispose();
    message.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Property Enquiry')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(widget.property.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 18),
          TextField(controller: name, decoration: const InputDecoration(labelText: 'Your Name', prefixIcon: Icon(Icons.person_outline))),
          const SizedBox(height: 12),
          TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Phone Number', prefixIcon: Icon(Icons.phone_outlined))),
          const SizedBox(height: 12),
          TextField(controller: message, maxLines: 4, decoration: const InputDecoration(labelText: 'Message', prefixIcon: Icon(Icons.message_outlined))),
          const SizedBox(height: 24),
          FilledButton(
            onPressed: submit,
            child: const Padding(
              padding: EdgeInsets.all(13),
              child: Text('Submit Enquiry'),
            ),
          ),
        ],
      ),
    );
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  Future<void> _call() async {
    await launchUrl(Uri(scheme: 'tel', path: '8299702322'));
  }

  Future<void> _whatsapp() async {
    await launchUrl(
      Uri.parse('https://wa.me/918604482766?text=${Uri.encodeComponent("Hello Akhtar Khan, I want property details.")}'),
      mode: LaunchMode.externalApplication,
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 100),
      children: [
        Center(
          child: Container(
            width: 120,
            height: 120,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.circular(35),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(.15), blurRadius: 20)],
            ),
            child: Image.asset('assets/logo.png'),
          ),
        ),
        const SizedBox(height: 18),
        const Center(child: Text('A. Square Property Agent Group', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900))),
        const SizedBox(height: 5),
        const Center(child: Text('Akhtar Khan • Real Estate Agent', style: TextStyle(color: Colors.black54))),
        const SizedBox(height: 28),
        _info(Icons.location_on_rounded, 'Mirzapur, Uttar Pradesh'),
        _info(Icons.home_work_rounded, 'Residential • Agriculture • Commercial • Flats'),
        _info(Icons.email_outlined, 'asquarepropertyagentgroup782@gmail.com'),
        const SizedBox(height: 22),
        FilledButton.icon(onPressed: _call, icon: const Icon(Icons.call_rounded), label: const Text('Call Agent')),
        const SizedBox(height: 10),
        OutlinedButton.icon(onPressed: _whatsapp, icon: const Icon(Icons.chat_rounded), label: const Text('WhatsApp Agent')),
      ],
    );
  }

  Widget _info(IconData icon, String text) {
    return Card(
      elevation: 0,
      color: Colors.white,
      child: ListTile(leading: Icon(icon, color: const Color(0xFF1265D8)), title: Text(text)),
    );
  }
}
